@echo off
title ADN TRADER - XAUUSD Terminal
set "APP=%~dp0ADN_TRADER.html"
set "URL=file:///%APP:\=/%"

where msedge >nul 2>&1
if %errorlevel%==0 (
    start "" msedge --app="%URL%" --window-size=1400,900
    goto :eof
)

where chrome >nul 2>&1
if %errorlevel%==0 (
    start "" chrome --app="%URL%" --window-size=1400,900
    goto :eof
)

start "" "%APP%"
