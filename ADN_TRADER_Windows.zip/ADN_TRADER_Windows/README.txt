ADN TRADER - XAUUSD Terminal (Windows)
======================================

1. Is folder ko kisi bhi jagah rakhein (jaise Desktop).
2. ADN_TRADER.bat par double-click karein.
   - Edge ya Chrome ki alag app window khulegi (browser ka address bar nahi dikhega).
3. Desktop shortcut chahiye? ADN_TRADER.bat par right-click > Send to > Desktop (create shortcut).

Note:
Ye version Binance se live PAXG/USDT price laata hai (internet chahiye, koi API key nahi).

Analysis tool hai, financial advice nahi. Risk management zaroor karein.

Login: app khulne par password maangega.
